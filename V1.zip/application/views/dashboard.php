<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Wisemx - Dispositivos</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<meta name="author" content="">

		<!-- Le styles -->
		
		<!--<link href="/css/bootstrap-responsive.css" rel="stylesheet">-->
		<link href="<?= base_url( 'resources/css/bootstrap.css' ) ?>" rel="stylesheet">
		<link href="<?= base_url( 'resources/kendo/styles/kendo.dataviz.min.css' ) ?>" rel="stylesheet">
		
		<style type="text/css">
			
			body {
				padding-top: 40px;
				padding-bottom: 40px;
				background-color: #f5f5f5;
			}

			.form-signin {
				max-width: 400px;
				padding: 19px 29px 29px;
				margin: 0 auto 20px;
				background-color: #fff;
				border: 1px solid #e5e5e5;
				-webkit-border-radius: 5px;
				   -moz-border-radius: 5px;
						border-radius: 5px;
				-webkit-box-shadow: 0 1px 2px rgba(0,0,0,.05);
				   -moz-box-shadow: 0 1px 2px rgba(0,0,0,.05);
						box-shadow: 0 1px 2px rgba(0,0,0,.05);
			}
			
			.form-signin .form-signin-heading,
			.form-signin .checkbox {
				margin-bottom: 10px;
			}
			
			.form-signin input[type="text"],
			.form-signin input[type="password"] {
				font-size: 16px;
				height: auto;
				margin-bottom: 15px;
				padding: 7px 9px;
			}
			
			.wise-icon{
				width: 45px;
				height: 45px;
			}
			/*
			.modal, .modal-body{
				width: 1100px;
				height: 510px;
			}
			
			.modal{
				margin: -300px 0 0 -550px;
			}
			*/
			.outer-well{
				width: 1025px;
				height: 340px;
			}
			
			.inner-well-left{
				width: 300px;
				height: 300px;
				box-shadow: 10px 10px -7px #888888;
			}
			
			.inner-well-right{
				width: 635px;
				height: 300px;
				box-shadow: 10px 10px -7px #888888;
			}
			
			.measurements{
				margin-top: 10px;
			}
			
			.gauge-container{
				margin: 5px;
				border-bottom: 1px solid #000000;
			}
			
			.bottom-text-h3{
				margin-top:.3em;
			}
			
			.bottom-text-h2{
				margin-top:.5em;
			}
			
			.sub-title{
				font-weight: bold;
				font-size: 10px;
				white-space: nowrap;
			}
			
			.span1{
				width: 80px;
			}
			
			#other_devices_table_wrapper,
			#hubs_devices_table_wrapper,
			#smart_plug_devices_table_wrapper,
			#other_devices_table_wrapper,
			#whole_house_devices_table_wrapper{
				display: none;
			}

			.devices_table{
				width: 750px;

			}
      
		</style>
    
    

		<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
		<!--[if lt IE 9]>
		  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

	</head>

	<body>

	
		<div class="container">
			
			<ul class="nav nav-tabs">
				
				<li class="dropdown active">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<i class="icon-home dropdown"></i>
						Mis Dispositivos
						<b class="caret"></b>
					</a>
					<ul class="dropdown-menu">
						<li class="active">
							<a href="#dropdown1" data-toggle="tab">Dispositivos existentes</a>
						</li>
						<li class="">
							<a href="#dropdown2" data-toggle="tab">Agregar dispositivo</a>
						</li>
					</ul>
              </li>
				
				<li>
					<a href="#users" data-toggle="tab" id="user_tab">
						<i class="icon-user"></i>
						Usuario
					</a>
				</li>
				<!--
				<li>
					<a href="#settings" data-toggle="tab">
						<i class="icon-cog"></i>
						Configuraciones
					</a>
				</li>
				-->
				<li>
					<a href="#close_session" data-toggle="tab">
						<i class="icon-off"></i>
						Cerrar Sesi&oacute;n
					</a>
				</li>
			</ul>
			
			<div class="tab-content">
				<div class="tab-pane" id="close_session"></div>
				<div class="tab-pane active" id="dropdown1">
					
					<pre id= "whole_house_devices_table_wrapper">
						<h2>WiseMeters</h2>
						<table class="table table-striped table-hover devices_table" id= "whole_house_devices_table">
							<tr>
								<th style= "width: 75px;">Imagen</th>
								<th>ID</th>
								<!--<th>Direcci&oacute;n MAC</th>-->
								<th></th>
								<!--<th>&Uacute;ltima fecha de actualización</th>
								<th>Tipo de ID</th>-->
								
							</tr>
							
						</table>
					</pre>
					
					<pre id= "smart_plug_devices_table_wrapper">
						<h2>WisePlugs</h2>
						<table class="table table-striped table-hover devices_table" id= "smart_plug_devices_table">
							<tr>
								<th style= "width: 75px;">Imagen</th>
								<th>ID</th>
								<!--<th>&Uacute;ltima fecha de actualización</th>
								<th>Tipo de ID</th>-->
								<th></th>
							</tr>
						</table>
					</pre>
					
					<pre id= "hubs_devices_table_wrapper">
						<h2>WiseHubs</h2>
						<table class="table table-striped table-hover devices_table" id= "hubs_devices_table">
							<tr>
								<th style= "width: 75px;">Imagen</th>
								<th>ID</th>
								<!--<th>&Uacute;ltima fecha de actualización</th>
								<th>Tipo de ID</th>-->
								<th></th>
							</tr>
						</table>
					</pre>
					
					<pre id= "other_devices_table_wrapper">
						<h2>Otros</h2>
						<table class="table table-striped table-hover devices_table" id= "other_devices_table">
							<tr>
								<th style= "width: 75px;">Imagen</th>
								<th>ID</th>
								<!--<th>&Uacute;ltima fecha de actualización</th>
								<th>Tipo de ID</th>-->
								<th></th>
							</tr>
						</table>
					</pre>
				
				</div>
				<div class="tab-pane" id="dropdown2">
					
					<form class="form-signin" id="form_agregar_dispositivo" action= "" method= "get" onSubmit= "return false;" >
						
						<h2 class="form-signin-heading">Llene todos los campos</h2>
						
						<input type="text" class="input-block-level" placeholder="Tipo de dispositivo" required="required" id= "tipo_id">
						<input type="text" class="input-block-level" placeholder="Direccion MAC de 16 caracteres" required="required" id= "id_dispositivo">
						<textarea rows="5" class="input-block-level" placeholder="Descripción" id= "descripcion"></textarea>
						
						<div class="alert alert-error" style= "display: none;" id= "error_message">
							<button type="button" class="close" data-dismiss="alert">×</button>
								<h4>Error!</h4>
								<p id= "error_message_body"></p>
						</div>
						
						<div class="alert alert-success" style= "display: none;" id= "success_msg">
							<button type="button" class="close" data-dismiss="alert">×</button>
								<h4>Exito!</h4>
								<p id= "success_body"></p>
						</div>
						
						<button class="btn btn-large btn-primary pull-left btn-block" type="submit" id= "agregar_dispositivo">Crear</button>
						<div class="clearfix"></div>
						<br />
						
						
					</form>
					
				</div>
				<div class="tab-pane" id="users">
					
					<form class="form-horizontal form-signin" id= "update_user_form">
						<fieldset>
						  <div id="legend" class="">
							<legend class="">Información de Usuario</legend>
						  </div>
						
						<div class="control-group">

							  <!-- Text input-->
							  <label class="control-label" for="input01">Empresa</label>
							  <div class="controls">
								<input type="text" placeholder="" class="input-large" id="empresa">
								<p class="help-block"></p>
							  </div>
							</div>

						<div class="control-group">

							  <!-- Text input-->
							  <label class="control-label" for="input01">Nombre</label>
							  <div class="controls">
								<input type="text" placeholder="" class="input-large" id="nombre">
								<p class="help-block"></p>
							  </div>
							</div>

						<div class="control-group">

							  <!-- Text input-->
							  <label class="control-label" for="input01">Apellido</label>
							  <div class="controls">
								<input type="text" placeholder="" class="input-large" id="apellido">
								<p class="help-block"></p>
							  </div>
							</div>

						<div class="control-group">

							  <!-- Text input-->
							  <label class="control-label" for="input01">Correo electrónico</label>
							  <div class="controls">
								<input type="text" placeholder="" class="input-large" id="correo">
								<p class="help-block"></p>
							  </div>
							</div>

						<div class="control-group">
							  <label class="control-label" for="input01">Contraseña</label>
							  <div class="controls">
								<input type="password" placeholder="" class="input-large" id= "password">
								<p class="help-block"></p>
							  </div>
							</div>

                        <div class="control-group">

                        <label class="control-label" for="input01">Confirmar contraseña</label>
                            <div class="controls">
                                <input type="password" placeholder="" class="input-large" id= "password_confirmacion">
                                <p class="help-block"></p>
                            </div>

							
							<div class="alert alert-success" style= "display: none;" id= "message">
							<button type="button" class="close" data-dismiss="alert">×</button>
								<h4>Éxito</h4>
								<p id= "error_message_body">Detalles guardados.</p>
							</div>

							<button class="btn btn-large btn-primary pull-left btn-block" type="submit" id= "update_user">Aceptar</button>
							<div class="clearfix"></div>

							<br />

						</fieldset>
					  </form>
					
				</div>
				<!--
				<div class="tab-pane" id="settings">
					Configuraciones Generales
				</div>
				-->
			</div>
      
       
		</div> <!-- /container -->

		<div id="modalMessage" class="modal hide fade" tabindex="-1" role="dialog" >
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal" ><i class="icon-remove"></i></button>
        				<h3 id="modalMessageHeader"></h3>
        			</div>
        			<div class="modal-body">
        				<p id= "modalMessageMessage" ></p>
        			</div>
        			<div class="modal-footer">
        				<button class="btn btn-danger btn-primary" data-dismiss="modal" aria-hidden="true">Close</button>
        			</div>
        </div>
		
		<div id="modal_device_history" class="modal hide fade large-modal" tabindex="-1" role="dialog" >
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" ><i class="icon-remove"></i></button>
				<h3 id="modalMessageHeader">Mediciones hist&oacute;ricas</h3>
			</div>
			<div class="modal-body">
				<div id="gauge-container">
					<div class="well outer-well">
					
						
						
						<div class="well inner-well-left pull-left">
							
							<div class= "gauge-container">
								<canvas id="gauge"></canvas>
							</div>
							
							<div class="row measurements">
								
								<div class="span1">
									<span class= "power-now">
										<h2 class= "pull-left">44</h2>
										<br />
										<p class= "pull-left bottom-text-h2">W</p>
										<p class= "pull-left" style= "margin: -5px 0px 10px 0px;"><small class= "sub-title">POWER NOW</small></p>
									</span>
								</div>
							
								<div class="span1">
									<span class= "power-today">
										<h3 class= "pull-left">44.9</h3>
										<br />
										<p class= "pull-left bottom-text-h3">kWh</p>
										
										<p class= "pull-left" style= "margin: -5px 0px 10px 0px;"><small class= "sub-title">SO FAR TODAY</small></p>
									</span>
								</div>
								
								<div class="span1">
									<span class= "power-average">
										<h3 class= "pull-left">24.3</h3>
										<br />
										<p class= "pull-left bottom-text-h3">kWh</p>
										
										<p class= "pull-left" style= "margin: -5px 0px 10px 0px;"><small class= "sub-title">DAILY AVERAGE</small></p>
									</span>
								</div>
								
							</div>
							
							
							
							
						</div>
						
						<div class="well inner-well-right pull-right">
							
						</div>
						
					</div>
					
				</div>
				
			</div>
			
			<div class="modal-footer">
				<button class="btn btn-danger btn-primary" data-dismiss="modal" aria-hidden="true">Close</button>
			</div>
			
		</div>

		<!-- Le javascript
		================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->
		
		<script src="<?= base_url( 'resources/js/jquery-1.8.2.js' ) ?>"></script>
		<script src="<?= base_url( 'resources/js/bootstrap.js' ) ?>"></script>
		<script src="<?= base_url( 'resources/kendo/js/kendo.dataviz.min.js' ) ?>"></script>
		<script src="<?= base_url( 'resources/js/gauge.min.js' ) ?>"></script>
		<script src="<?= base_url( 'resources/js/wisemx.js' ) ?>"></script>
		
		<script>
               
                $(document).ready(function() {
                    var opts = {
						  lines: 8, // The number of lines to draw
						  angle: 0.35, // The length of each line
						  lineWidth: 0.1, // The line thickness
						  pointer: {
							length: 0.9, // The radius of the inner circle
							strokeWidth: 0.035, // The rotation offset
							color: '#000000' // Fill color
						  },
						  fontSize: 14,
						  colorStart: '#6F6EA0',   // Colors
						  colorStop: '#5BB75B',    // just experiment with them
						  strokeColor: '#EEEEEE',   // to see which ones work best for you
						  generateGradient: true
						};
						var target = document.getElementById('gauge'); // your canvas element
						var gauge = new Donut(target).setOptions(opts); // create sexy gauge!
						gauge.maxValue = 100; // set max gauge value
						gauge.animationSpeed = 32; // set animation speed (32 is default value)
						gauge.set(80); // set actual value
                });
            </script>
    

	</body>

</html>
