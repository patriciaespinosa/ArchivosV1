<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Wisemx - Acceso</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<meta name="author" content="">

		<!-- Le styles -->
		
		<!--<link href="/css/bootstrap-responsive.css" rel="stylesheet">-->
		<link href="<?= base_url( 'resources/css/bootstrap.css' ) ?>" rel="stylesheet">
		
		
		<style type="text/css">
			
			body {
				padding-top: 40px;
				padding-bottom: 40px;
				background-color: #f5f5f5;
			}

			.form-signin {
				max-width: 300px;
				padding: 19px 29px 29px;
				margin: 0 auto 20px;
				background-color: #fff;
				border: 1px solid #e5e5e5;
				-webkit-border-radius: 5px;
				   -moz-border-radius: 5px;
						border-radius: 5px;
				-webkit-box-shadow: 0 1px 2px rgba(0,0,0,.05);
				   -moz-box-shadow: 0 1px 2px rgba(0,0,0,.05);
						box-shadow: 0 1px 2px rgba(0,0,0,.05);
			}
			
			.form-signin .form-signin-heading,
			.form-signin .checkbox {
				margin-bottom: 10px;
			}
			
			.form-signin input[type="text"],
			.form-signin input[type="password"] {
				font-size: 16px;
				height: auto;
				margin-bottom: 15px;
				padding: 7px 9px;
			}
      
		</style>
    
    

		<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
		<!--[if lt IE 9]>
		  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

	</head>

	<body>

	
		<div class="container">

			

			<form class="form-signin" action= "" method= "get" onSubmit= "return false;" >
				<img src= "<?= base_url( 'resources/img/logo_jpg.jpg' ) ?>">
				<br /><br />
				<div class="clearfix"></div>
				<h2 class="form-signin-heading">Acceso a usuario</h2>
				<input type="email" class="input-block-level" placeholder="Correo electr&oacute;nico"  id= "email" value="">
				<input type="password" class="input-block-level" placeholder="Contraseña" id= "password">
				
				
				<div class="alert alert-error" style= "display: none;" id= "error_message">
					<button type="button" class="close" data-dismiss="alert">×</button>
						<h4>Error!</h4>
						<p id= "error_message_body"></p>
				</div>
				<button class="btn btn-large btn-primary btn-success btn-block" type="submit" id= "login">Ingresar</button>
				<button class="btn btn-large btn-block" type="submit" id= "signUp" onSubmit= "return false;">Registrarse</button>
				<div class="clearfix"></div>
				<br />
				<label class="checkbox muted" style= "display: none;">
					<input type="checkbox" value="remember-me" id= "rememberme" > Recordar
				</label>
				
			</form>
      
       
		</div> <!-- /container -->
		
		<div id="modalMessage" class="modal hide fade" tabindex="-1" role="dialog" >
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" ><i class="icon-remove"></i></button>
				<h3 id="modalMessageHeader"></h3>
			</div>
			<div class="modal-body">
				<p id= "modalMessageMessage" ></p>
			</div>
			<div class="modal-footer">
				<button class="btn btn-danger btn-primary" data-dismiss="modal" aria-hidden="true">Close</button>
			</div>
		</div>

		<!-- Le javascript
		================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->
		
		<script src="<?= base_url( 'resources/js/jquery-1.8.2.js' ) ?>"></script>
		<script src="<?= base_url( 'resources/js/bootstrap.js' ) ?>"></script>
		<script src="<?= base_url( 'resources/js/wisemx.js' ) ?>"></script>
		
    

	</body>

</html>
