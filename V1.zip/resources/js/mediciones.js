
	var locationid;
	var userKey;
	var baseURL =  'http://developer.peoplepowerco.com/espapi/rest/json';
	var baseAdminURL =  'http://developer.peoplepowerco.com/espapi/admin';

	$(function() {

		// Radial Gaugage
		var gasto_actual= get_gasto_actual( localStorage.getItem("current_device") );
		createGauge( gasto_actual );
		
		$(document).bind("kendo:skinChange", function(e) {
			createGauge();
		});
		

		// Column Chart
		setTimeout(
			function() {
                       
				createChart();

				$("#example").bind("kendo:skinChange", function(e) {
					createChart();
				});
			}, 400
		);

		// Cambia en el dropdown la opción y se obtienen mediciones de un lapso de tiempo distint
		$( '#historial_dropdown' )
			.on(
				'change',
				function(){

                    var fecha_hoy= new Date();
					var lapso_tiempo=  $('option:selected', this).val();
					var chart= $("#chart").data("kendoChart");
					var series = chart.options.series;
					var categorias= chart.options.categoryAxis;

					var mes;
					var dia;
                    var dia_siguiente;

					switch( lapso_tiempo ){

						case '1':
						
							mes= ( fecha_hoy.getMonth() + 1 ) < 10 ? '0' + ( fecha_hoy.getMonth() + 1 ) : ( fecha_hoy.getMonth() + 1 );
							dia= fecha_hoy.getDate() < 10 ? '0' + fecha_hoy.getDate() : fecha_hoy.getDate();
                            dia_siguiente= fecha_hoy.getDate() + 1;
                            dia_siguiente= dia_siguiente < 10 ? '0' + dia_siguiente : dia_siguiente;
							var mediciones= get_mediciones( 1, fecha_hoy.getFullYear() + '-' + mes + '-' + dia, fecha_hoy.getFullYear() + '-' + mes + '-' + dia_siguiente );
							
							series[0].data = mediciones;
							categorias.categories = [
								'12am', '1am', '2am', '3am', '4am', '5am', '6am', '7am', '8am', '9am', '10am', '11am',
								'12pm', '1pm', '2pm', '3pm', '4pm', '5pm', '6pm', '7pm', '8pm', '9pm', '10pm', '11pm',
							];
						break;

						case '2':
							
							var fecha_domingo= new Date( fecha_hoy.setDate( fecha_hoy.getDate() - fecha_hoy.getDay() ) );
							var dia_domingo= fecha_domingo.getDate();

							var fecha_sabado= new Date( fecha_hoy.setDate(  ( 6 - fecha_hoy.getDay() ) + fecha_hoy.getDate() ) );
							var dia_sabado= fecha_sabado.getDate();

							if( dia_domingo < 10 ){
								dia_domingo= '0' + fecha_domingo.getDate();
							}

							if( dia_sabado < 10 ){
								dia_sabado= '0' + dia_sabado;
							}
							
							var mes_1= ( fecha_domingo.getMonth() + 1 ) < 10 ? '0' + ( fecha_domingo.getMonth() + 1 ) : ( fecha_domingo.getMonth() + 1 );
							var mes_2= ( fecha_sabado.getMonth() + 1 ) < 10 ? '0' + ( fecha_sabado.getMonth() + 1 ) : ( fecha_sabado.getMonth() + 1 );

							var mediciones= get_mediciones( 2, fecha_domingo.getFullYear() + '-' + mes_1 + '-' + dia_domingo, fecha_sabado.getFullYear() + '-' + mes_2 + '-' + dia_sabado );
							series[0].data = mediciones;
							categorias.categories = ['Domingo', 'Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado'];
						break;

						case '3':
						
							/*var mediciones= ( 4, fecha_hoy.getFullYear() + '-01-01', new Date( fecha_hoy.getFullYear(), fecha_hoy.getFullYear() + 1, 0).getDate() );*/
							mes= ( fecha_hoy.getMonth() + 1 ) < 10 ? '0' + ( fecha_hoy.getMonth() + 1 ) : ( fecha_hoy.getMonth() + 1 );
							
							var ultimo_dia= new Date( fecha_hoy.getFullYear(), fecha_hoy.getFullYear() , 0).getDate();
							
							var mediciones= get_mediciones( 4, fecha_hoy.getFullYear() + '-' + mes + '-01', fecha_hoy.getFullYear() + '-' + mes + '-' + ultimo_dia ); 

							series[0].data = mediciones;
							//categorias.categories = ['Semana 1', 'Semana 2', 'Semana 3', 'Semana 4'];
							categorias.categories = get_weekCount( fecha_hoy.getFullYear(), fecha_hoy.getMonth() + 1 );
						break;

						case '4':
							var mediciones= get_mediciones( 3, fecha_hoy.getFullYear() + '-01-01', fecha_hoy.getFullYear() + '-12-31' );
							series[0].data = mediciones;
							categorias.categories = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
						break;

					}

					
					
					
					chart.refresh();

					/*
					var gauge = $("#gauge").data("kendoRadialGauge");
					var options = gauge.options;
					options.pointer.value= 50;
					gauge.redraw();
					*/
				}
			);
		

	});
	
	function get_weekCount(year, month_number) {

		// month_number is in the range 1..12
		var weeks_in_month= [];
		var firstOfMonth = new Date(year, month_number-1, 1);
		var lastOfMonth = new Date(year, month_number, 0);
		var used = firstOfMonth.getDay() + lastOfMonth.getDate();
		
		for( var i= 1; i<= Math.ceil( used / 7); i+= 1  ){
			weeks_in_month.push( 'Semana ' + i );
		}

		return weeks_in_month;
	}

	function get_mediciones( lapso_tiempo, fecha_inicial, fecha_final ){

		var requestUrl= baseURL + '/deviceEnergyUsage/' + localStorage.getItem("userKey") + "/" + localStorage.getItem("locationId") + '/' + lapso_tiempo + '/' + fecha_inicial + '?endDate=' + fecha_final + '&deviceId=' + localStorage.getItem("current_device");
		//var requestUrl= baseURL + '/deviceEnergyUsage/' + localStorage.getItem("userKey") + "/" + localStorage.getItem("locationId") + '/' + lapso_tiempo + '/2012-10-17?endDate=2012-10-18&deviceId=' + localStorage.getItem("current_device");
		
		var resultados= [];
		var mediciones= {};

		//console.log( requestUrl );

		$.ajax({
            url:requestUrl,
            type:"GET",
            dataType:"json",
            async: false,
             success:
             	function( data ){

             		//var ultima_lectura= data.response.readings.reading[ data.response.readings.reading.length - 1 ];
             		//alert( ultima_lectura['@timeStamp'] );
             		if( data.response.usages != undefined ){

	             		mediciones= data.response.usages.device.usage;

	             		for( medicion in mediciones ){
	             			resultados.push( mediciones[ medicion ].kWh );

	             		}
	             		//console.log( resultados );
	             		//console.log( data );
	             		//resultados= data;
	             	}else{
	             		resultados= [0];
	             	}
             		
             		

             	}
             ,
            cache:false
        });

        return resultados;


	}

	function get_gasto_actual( device_id ){

        var fecha_hoy= new Date();
		var gasto_actual= 0;
		var costo_actual= 0;
		var promedio_diario= 0;
		var requestUrl_historico = baseURL + "/deviceCurrentEnergyUsage/" + localStorage.getItem("userKey") + "/" + localStorage.getItem("locationId") + '?deviceId=' + device_id;
		var requestUrl_instantaneo= baseURL + "/deviceReadings/" + localStorage.getItem("userKey") + "/" + localStorage.getItem("locationId") + '/' + device_id + "/" +fecha_hoy.getFullYear()+ "-01-01?endDate=" + ( parseInt(fecha_hoy.getFullYear()) + 1 ) + "-12-31";

		console.log( "deviceReadings: " + requestUrl_instantaneo );
		console.log( "deviceCurrentEnergyUsage: " + requestUrl_historico );
		

		$.ajax({
            url:requestUrl_instantaneo,
            type:"GET",
            dataType:"json",
            async: false,
             success:
             	function( data ){

					console.log( data );
					
             		var ultima_lectura= data.response.readings.reading[ data.response.readings.reading.length - 1 ];
					
					
					/*
					console.log( "largo" + data.response.readings.reading.length );
					console.log( '0' + requestUrl_instantaneo );
             		console.log( '1: ' + ultima_lectura );
             		console.log( '2: ' + ultima_lectura.param.$ );
             		console.log( '3: ' + ultima_lectura.param[0].$ );
             		*/
             		
             		try{ 
						gasto_actual= ultima_lectura.param[3].$;
					
					}catch( e ){
						console.log( e );
						gasto_actual= 0;
					}
             		
             		console.log( gasto_actual );
             		//gasto_actual= ultima_lectura.param.$;
             		$( '#etiqueta_gasto_actual' ).text( parseFloat( gasto_actual ) );
             		//$( '#etiqueta_gasto_actual' ).text( gasto_actual.substring(0,5) );

             		//costo_actual=  ultima_lectura.param[3].$;
             		//$( '#etiqueta_gasto_hoy' ).text( costo_actual.substring(0,4) );
             		
             	}
             ,
            cache:false
        });

		$.ajax({
            url:requestUrl_historico,
            type:"GET",	
            dataType:"json",
            async: false,
             success:
             	function( data ){

             		costo_actual=  data.response.device.energy.kWhDTD;
             		console.log( "Costo actual: " + costo_actual );
             		$( '#etiqueta_gasto_hoy' ).text( costo_actual );
             		//$( '#etiqueta_gasto_hoy' ).text( costo_actual.substring(0,5) );

					/* Es el gasto del mes actual */
             		promedio_diario= data.response.device.energy.kWh;
             		$( '#etiqueta_promedio_diario' ).text( promedio_diario );
             		//$( '#etiqueta_promedio_diario' ).text( promedio_diario.substring(0,5) );
             		
             	}
             ,
            cache:false
        });


        //
        
		return gasto_actual;

	}


	function createGauge( gasto_actual ) {

		$("#gauge").kendoRadialGauge({
			
			theme: $(document).data("kendoSkin") || "default",
	        pointer: {
				value: gasto_actual
			},

	        scale: {
	        	minorUnit: 1,
	            startAngle: -70,
	            endAngle: 250,
	            max: 500,
	            labels: {
	            	position: "outside"
				},
	            ranges: [
	            	{
	                	from: 200,
	                    to: 280,
	                    color: "#ffc700"
					}, {
	                	from: 280,
	                    to: 420,
	                    color: "#ff7a00"
					}, {
	                	from: 420,
	                    to: 500,
	                    color: "#c20000"
					}
				]
			}
		});
	}

	function createChart() {

        var fecha_hoy= new Date();
        var dia= fecha_hoy.getDate() < 10 ? '0' + fecha_hoy.getDate() : fecha_hoy.getDate();
        var dia_siguiente= fecha_hoy.getDate() + 1;
        var dia_siguiente= dia_siguiente < 10 ? '0' + dia_siguiente : dia_siguiente;
        var mes= ( fecha_hoy.getMonth() + 1 ) < 10 ? '0' + ( fecha_hoy.getMonth() + 1 ) : ( fecha_hoy.getMonth() + 1 );

    	$("#chart").kendoChart({
        	
        	theme: $(document).data("kendoSkin") || "default",
            title: {
            	text: "Historial de Consumo"
			},
            legend: {
            	position: "bottom"
			},
            seriesDefaults: {
            	type: "column"
			},
            series: [{
            	name: "kWh",
                	data: get_mediciones( 1, fecha_hoy.getFullYear() + '-' + mes + '-' + dia, fecha_hoy.getFullYear() + '-' + mes + '-' + dia_siguiente )
			}],
            valueAxis: {
            	labels: {
                format: "{0}KWh"
				}	
            },
            categoryAxis: {
            	categories : [
								'12am', '1am', '2am', '3am', '4am', '5am', '6am', '7am', '8am', '9am', '10am', '11am',
								'12pm', '1pm', '2pm', '3pm', '4pm', '5pm', '6pm', '7pm', '8pm', '9pm', '10pm', '11pm',
							]
			},
            tooltip: {
            	visible: false,
                format: "{0}KWh"
			},
            chartArea:{
				background: "",
				width: 770,
				heigt: 350
			}
		});

	}

