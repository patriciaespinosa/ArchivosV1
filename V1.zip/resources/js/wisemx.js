var locationid;
	var userKey;
	var baseURL =  'http://developer.peoplepowerco.com/espapi/rest';
	var baseAdminURL =  'http://developer.peoplepowerco.com/espapi/admin';

	$(function() {
		
		if( user_is_logged() ){
			
			if( document.URL.search( 'dashboard' ) == '-1' ){
				window.location.href= "dashboard";
			}else{
				getDevices();
			}
				
				
		}else{
			
			if( document.URL.search( 'dashboard' ) != '-1' || document.URL.search( 'mediciones' ) != '-1' ){
				window.location.href= "welcome";
			}
			
		}

		$( '#update_user' )
			.click(

				function( evt ){

					evt.preventDefault();
					
					update_user();

				}

			);

		$( '#agregar_dispositivo' )
			.click(

				function( evt ){

					evt.preventDefault();
					agregar_dipositivo();		
				}

			);

		$( '#do_signUp' )
			.click(
				
				function( evt ){

                    evt.preventDefault();
					registrar_usuario();
				}
			
			);
		
		$( '#signUp' )
			.click(
				
				function( event ){
					window.location.href= "signup";
				}
			
			);

		$( '#cancelar_signup' )
			.click(
				
				function( event ){
					
					window.location.href= "welcome";
				}
			
			);
		
		$( '#login' )
			.click(
					
				function(){
					switch( validate_fields() ){
						
						case 1:
							doLogin();
						break;
							
						case 2:
							show_message( 'Correo incorrecto' );
						break;
							
						case 3:
							show_message( 'Llene todos los campos' );
						break;
							
					}
				}
				
			);
			
		$('a[data-toggle="tab"]:last')
			.on(
				'shown', 
				function( e ){
					localStorage.clear(); 
					window.location.href= "welcome";
						
				}
			);

		$('a[data-toggle="tab"]#user_tab')
			.on(
				'shown', 
				function( e ){

					$( '#empresa' ).val( localStorage.getItem( 'empresa' ) );
					$( '#nombre' ).val( localStorage.getItem( 'nombre_usuario' ) );
					$( '#apellido' ).val( localStorage.getItem( 'apellido_usuario' ) );
					$( '#correo' ).val( localStorage.getItem( 'correo_usuario' ) );
					$( '#correo' ).val( localStorage.getItem( 'correo_usuario' ) );
					$( '#password' ).val( localStorage.getItem( 'password' ) );
                    $( '#password_confirmacion' ).val( localStorage.getItem( 'password' ) );

						
				}
			);
	
	});

    function registrar_usuario(){

        var campos_vacios= false;
        var user= "";

        $( 'form#signup_form' )
            .find( ':input' ).not( ':submit, :button' )
            .each(
            function(){

                if( $( this ).val() == '' || $( this ).val().length<= 0 ){
                    campos_vacios= true;

                }

            }
        );

        if( campos_vacios ){

            show_message( 'Llene todos los campos' );
        }else{


            user= "<request><user><username>" + $( '#username' ).val() + "</username><password>" + $( '#password_signup' ).val() + "</password><firstName>" + $( '#first_name' ).val() + "</firstName><lastName>" + $( '#last_name' ).val() + "</lastName><email>" + $( '#email' ).val() + "</email></user></request>"

            //var requestURL= baseURL + '/json/user/' +localStorage.getItem("userKey")+ '/password/' + $('#password').val() + '/firstName/' + $('#nombre').val() + '/lastName/' + $('#apellido').val() + '/email/' +  $('#correo').val();
            //var requestURL= baseURL + '/json/user/' +localStorage.getItem("userKey")+ '/' + JSON.stringify( user );
            var requestURL= baseURL + '/json/user';

            $.ajax({
                url:requestURL,
                type:"POST",
                dataType:"xml",
                data: user,
                async: false,
                success:
                    function( data ){


                        if( data.response.resultCode == 0 ){

                            show_message( "Usuario creado con &eacute." );

                        }else{

                            show_message( "Usuario no creado." );
                        }

                    },
                error:
                    function( data, status, byKey ){

                        if( JSON.parse( data.responseText ).response.resultCode == 0 ){

                            $( '#modalMessageHeader' ).html( 'Exito' );
                            $( '#modalMessageHeader' ).addClass( 'text-success' );
                            $( '#modalMessageMessage' ).html( "Usuario creado con &eacute;xito." );
                            $( '#modalMessage' ).modal( 'show' );

                        }else{

                            $( '#modalMessageHeader' ).html( 'Error' );
                            $( '#modalMessageHeader' ).addClass( 'text-warning' );
                            $( '#modalMessageMessage' ).html( "Usuario no creado." );
                            $( '#modalMessage' ).modal( 'show' );

                        }
                        console.log( user );
                        console.log( data );
                        console.log( status );



                    },
                cache:false
            });
            console.log( requestURL );



        }


    }

    function redireccionar_home(){

        window.location.href= "welcome";

    }
	
	function  update_user(){



		var campos_vacios= false;

		$( 'form#update_user_form' )
			.find( ':input' ).not( ':submit, :button' )
			.each(
				function(){
					
					
					if( $( this ).val() == '' || $( this ).val().length<= 0 ){
						campos_vacios= true;
						
					}
					
				}
			);





		if( campos_vacios ){
            $( '#modalMessageHeader' ).html( 'Error' );
            $( '#modalMessageHeader' ).addClass( 'text-warning' );
            $( '#modalMessageMessage' ).html("Llene todos los campos." );
            $( '#modalMessage' ).modal( 'show' );

		}else{

            if( $( '#password' ).val() != $( '#password_confirmacion' ).val() ) {

                $( '#modalMessageHeader' ).html( 'Error' );
                $( '#modalMessageHeader' ).addClass( 'text-warning' );
                $( '#modalMessageMessage' ).html( "Las contraseñas deben coincidir." );
                $( '#modalMessage' ).modal( 'show' );

            }else{

                user= "<request><user><username>" + $( '#correo' ).val() + "</username><password>" + $( '#password' ).val() + "</password><firstName>" + $( '#nombre' ).val() + "</firstName><lastName>" + $( '#apellido' ).val() + "</lastName><email>" + $( '#correo' ).val() + "</email></user></request>"

                //var requestURL= baseURL + '/json/user/' +localStorage.getItem("userKey")+ '/password/' + $('#password').val() + '/firstName/' + $('#nombre').val() + '/lastName/' + $('#apellido').val() + '/email/' +  $('#correo').val();
                //var requestURL= baseURL + '/json/user/' +localStorage.getItem("userKey")+ '/' + JSON.stringify( user );
                var requestURL= baseURL + '/user/' +localStorage.getItem("userKey");

                $.ajax({
                    url:requestURL,
                    type:"POST",
                    dataType:"xml",
                    data: user,
                    async: false,
                    success:
                        function( data ){

                             var start = new Date().getTime();
                             $( '#message' ).show();

                             setTimeout(function(){

                                 var start = new Date().getTime();
                                 while ((new Date().getTime() - start) < 3000){

                                 }
                             },0);


                             localStorage.clear();
                             window.location.href= "welcome";

                        },
                     error:
                        function(){



                        },
                    cache:false
                });
                console.log( requestURL );
            }



		}

	}

	function agregar_dipositivo(){

		var campos_vacios= false;

		$( '#form_agregar_dispositivo' )
			.find( ':input' ).not( ':submit, :button' )
			.each(
				function(){
					
					if( $( this ).val() == '' ){
						campos_vacios= true;
						
					}
					
				}
			);

		if( campos_vacios ){

			show_message( 'Llene todos los campos' );
		}else{
			var id_dispositivo= $( '#id_dispositivo' ).val();
			var tipo_id= $( '#tipo_id' ).val();
			var requestURL= baseURL + '/json/deviceRegistration/' + localStorage.getItem("userKey") + "/" + localStorage.getItem("locationId") + '/' + id_dispositivo + '?deviceType=' + tipo_id;

			$.ajax({
	            url:requestURL,
	            type:"POST",
	            dataType:"json",
	            async: false,
	             success:
	             	function( data ){

	             		if( data.response.resultCode != '0' ){
	             			show_message( 'Error al dar de alta dispositivo. Error: ' + data.response.resultCodeDesc );
	             		}else{
	             			show_success_message( 'Dispositivo agregado correctamente.' );

	             		}
	             		
	             	}
	             ,
	            cache:false
	        });

		}
	}



	function show_device_history( device_id ){

		//$( '#modal_device_history' ).modal( 'show' );
		localStorage.setItem("current_device", device_id);
		window.location.href= "mediciones";
		
	}
	
	function user_is_logged(){
		var rememberme= localStorage.getItem("rememberme");
		var userkey= localStorage.getItem("userKey");
		
		if( rememberme== 'true' ){
			if( userkey!= '' && userKey!= 'undefined' ){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
		
	}
	
	function validate_fields(){
		
		if( $('#email').val()== '' || $('#password').val()== '' ){
			return 3;
		}else{
			if( !($('#email').val().indexOf(".") > 2) && !($('#email').val().indexOf("@") > 0) ){
				return 2;
			}else{
				return 1;
			}
		}
		
	}
	
	function show_message( message ){
		
		$( '#error_message_body').text( message );
		$( '#error_message' )
			.fadeIn( 
				1500,
				function(){
					$( this ).fadeOut( 5000 );
				}
			);
		
	}
	
	function show_success_message( message ){
		
		$( '#success_body').text( message );
		$( '#success_msg' )
			.fadeIn( 
				1500,
				function(){
					$( this ).fadeOut( 5000 );
				}
			);
		
		
	}
	
	function doLogin(){
		

		var email= $( '#email' ).val();
		var password= $( '#password' ).val();
		var requestUrl = baseURL + "/json/login/" + email + "/" + password + "/-1/1";
    	
    	//$("#maskPgIndex").append("<div style='height:100%; width:100%; position: absolute; z-index: 90000;'></div>");
    	
        $.ajax({
            url:requestUrl,
            type:"GET",
            async: true,
            dataType:"json",
            success:loginSuccess,
            error:failedLogin,
            cache:false

        });
		
	}
	
	function loginSuccess(data, status, byKey){
		
		if (data.response.resultCode == 0) {
			
			var userKey = data.response.key;
			//saveKey(userKey);

			// login success, begin to retrieve user detail information
			var requestUrl = baseURL + "/json/user/" + userKey;
			$.ajax({
				url:requestUrl,
				type:"GET",
				dataType:"json",
				success:getUserHandler,
				error:failedHandler,
				cache:false
			});
			
			 
			localStorage.setItem("rememberme", "true");
			localStorage.setItem("loginByKey", "false");
			localStorage.setItem("password", $( '#password' ).val());
			localStorage.setItem("userKey", userKey);
		
		}else{
			
			$( '#modalMessageHeader' ).html( 'Error' );
			$( '#modalMessageHeader' ).addClass( 'text-warning' );
			$( '#modalMessageMessage' ).html( data.response.resultCodeDesc );
			$( '#modalMessage' ).modal( 'show' );
			
			//showErrorMessage($('#pgSignin-outr'), 'failLogin', 'Authentication failed, please verify your input.');
		}
		
		
	}
	
	function failedLogin(data, status, byKey){
		$( '#modalMessageHeader' ).html( 'Error' );
		$( '#modalMessageHeader' ).addClass( 'text-warning' );
		$( '#modalMessageMessage' ).html( "An error ocurred. Please try again later. " + data.response.resultCodeDesc );
		$( '#modalMessage' ).modal( 'show' );
	}
	
	function getUserHandler(data, status){

		var requestUrl = baseURL + "/json/user/" + userKey;
        $.ajax({
            url:requestUrl,
            type:"GET",
            dataType:"json",
            success:getUserHandlers,
            error:failedHandler,
            cache:false
        });


        //console.log( data.response );

        locationid= data.response.locations.location[ '@id' ];
        localStorage.setItem("locationId", data.response.locations.location[ '@id' ] );
        localStorage.setItem("correo_usuario", data.response.user.email.$ );
        localStorage.setItem("nombre_usuario", data.response.user.firstName );
        localStorage.setItem("apellido_usuario", data.response.user.lastName );
        localStorage.setItem("empresa", data.response.locations.location.addrStreet1 );

		window.location.href= "dashboard";

	}

	function getUserHandlers(){}

	function failedHandler(data, status, byKey){
		
	}

	function getDevices(){
		var requestUrl = baseURL + "/json/deviceInfo/" + localStorage.getItem("userKey") + "/" + localStorage.getItem("locationId");

		
		$.ajax({
			url : requestUrl,
			type : "GET",
			dataType : "json",
			success : createDevicesList,
			error : failedHandler
		});
		
		//window.location.href= "dashboard";

	}

	function createDevicesList(data, status){
		
		var device_row= '';
		var devices= data.response.devices.device;
		var device_id= "";
		var device_type= "";
		var last_data_received_date= "";
		var type_category= "";
		
		console.log( "Dispositivo : " + data );
		
		for(device in devices){
		
				
			
			device_id= devices[ device ]['@id'];
			device_type= devices[ device ]['@type'];
			type_category= devices[ device ]['@typeCategory'];
			last_data_received_date= devices[ device ]['@lastDataReceivedDate'];
			
			
			switch( device_type ){
				
				// wiseMeter Nemo
				case '5101':
					device_row= "<tr>" +
									"<td><img src='../WiseEnergy/resources/img/productos/producto_2.jpg' class='img-polaroid pull-left wise-icon' /></td>" +
									"<td>" + device_id + "</td>" +
									
									"<td> <a class='brand' href='#' id='" + device_id + "' onclick= 'show_device_history( this.id );'>Ver mediciones</a></td>" +
								"</tr>";
					append_devices_to_table( 'whole_house_devices_table', device_row );
				break;
				
				// wiseMeter 3I1V
				case '5102':
					device_row= "<tr>" +
									"<td><img src='../WiseEnergy/resources/img/productos/producto_2.jpg' class='img-polaroid pull-left wise-icon' /></td>" +
									"<td>" + device_id + "</td>" +
									
									"<td> <a class='brand' href='#' id='" + device_id + "' onclick= 'show_device_history( this.id );'>Ver mediciones</a></td>" +
								"</tr>";
					append_devices_to_table( 'whole_house_devices_table', device_row );
				break;
				
				//wiseHubs
				case '5100':
					device_row= "<tr>" +
									"<td><img src='../WiseEnergy/resources/img/productos/producto_3.jpg' class='img-polaroid pull-left wise-icon' /></td>" +
									"<td>" + device_id + "</td>" +
									"<td></td>" +
								"</tr>";
					append_devices_to_table( 'hubs_devices_table', device_row );
				break;
				
				//wisePlug
				case '10004':
					device_row= "<tr>" +
									"<td><img src='../WiseEnergy/resources/img/productos/producto_1.jpg' class='img-polaroid pull-left wise-icon' /></td>" +
									"<td>" + device_id + "</td>" +
									
								"</tr>";
					append_devices_to_table( 'smart_plug_devices_table', device_row );
				break;
			
				default:
					device_row= "<tr>" +
									"<td><img src='' class='img-polaroid pull-left wise-icon' /></td>" +
									"<td>" + device_id + "</td>" +
									"<td></td>" +
								"</tr>";
					append_devices_to_table( 'other_devices_table', device_row );
				break;
			}
			
		}
		
	}

	function append_devices_to_table( id_table, device_row ){
		
		$( '#' + id_table ).append( device_row );
		$( '#' + id_table + '_wrapper' ).show();
	}